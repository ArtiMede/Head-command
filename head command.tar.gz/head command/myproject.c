#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<errno.h>
#include<fcntl.h>
int main(int argc, char *argv[]) {
//open file//
	int fd, i, x, count=0;
	char ch;
	int n;
	if(argc<2) {
		errno = EINVAL;
		perror("Bad Arguments:");
		return errno;
	}
	fd = open(argv[1], O_RDONLY);
	if(fd == -1) {
		perror("open failed:");
		return errno;
	}
//Print//
//take number of lines as input n and take loop as for n number of \n and then print it//
	printf("Enter number of lines to be printed\n");
	scanf("%d",&n);
	 
	//putchar till n number of \n
			for(i = 0;i<n;i++){
			read(fd, &ch, 1);
			while(ch != '\n') {
			 read(fd, &ch, 1);
				putchar(ch);
			}
			
	}
	
	close(fd);
return 0;
}
// add: convert space  also into binary// 
